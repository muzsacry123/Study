import numpy as np
import argparse

def sigmoid(x):
    """
    Implementation of the sigmoid function.

    Parameters:
        x (str): Input np.ndarray.

    Returns:
        An np.ndarray after applying the sigmoid function element-wise to the
        input.
    """
    e = np.exp(x)
    return e / (1 + e)


def train(theta, X, y, num_epoch, learning_rate):
    for i in range(num_epoch):
        print('finish %.2f%%'%((i+1)/num_epoch*100))
        for i in range(len(X)):  
            gradient = (sigmoid(theta @ X[i].T) - y[i]) * X[i]
            theta -= learning_rate * gradient


def predict(theta, X):
    result = sigmoid(theta@X.T).T
    result[result >= 0.5] = 1
    result[result < 0.5] = 0
    return result


def compute_error(y_pred, y):
    error = np.sum(y_pred != y)
    errorRate = error / len(y)
    return errorRate


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='hw4')
    parser.add_argument('formatted_train_input', type = str,                  
                        help = 'path to the formatted training input .tsv file')
    parser.add_argument('formatted_validation_input', type = str,                  
                        help = 'path to the formatted validation input .tsv file')
    parser.add_argument('formatted_test_input', type = str,
                        help = 'path to the formatted test input .tsv file')
    parser.add_argument('train_out', type = str,
                        help = 'path to output training prediction .txt file')   
    parser.add_argument('test_out', type = str,
                        help = 'path to output test prediction .txt file')
    parser.add_argument('metrics_out', type = str, 
                        help = 'path to output metrics .txt file')
    parser.add_argument('num_epoch', type = int, 
                        help = 'integer specifying the number of times SGD loops')
    parser.add_argument('learning_rate', type = float, 
                        help = 'float specifying the learning rate')
    
    args = parser.parse_args()
    
    
    
    dataTrainFile = args.formatted_train_input
    dataTrain = []
    with open(dataTrainFile, 'r') as f:
        for line in f.readlines():
            dataTrain.append(line.split())
    dataTrain = np.array(dataTrain)
    yTrain = dataTrain[:, 0].astype('float64')
    XTrain = dataTrain[:, 1:].astype('float64')
    XTrain = np.concatenate((np.ones((len(XTrain),1)), XTrain), axis = 1)
    theta = np.zeros((XTrain.shape[1], ))
    train(theta, XTrain, yTrain, args.num_epoch, args.learning_rate)
    yPredTrain = predict(theta, XTrain)
    errorTrain = compute_error(yPredTrain, yTrain)
    with open(args.train_out, 'w') as f:
        for pred in yPredTrain:
            f.write(str(pred) + '\n')
    
    dataTestFile = args.formatted_test_input
    dataTest = []
    with open(dataTestFile, 'r') as f:
        for line in f.readlines():
            dataTest.append(line.split())
    dataTest = np.array(dataTest)
    yTest = dataTest[:, 0].astype('float64')
    XTest = dataTest[:, 1:].astype('float64')
    XTest = np.concatenate((np.ones((len(XTest),1)), XTest), axis = 1)
    yPredTest = predict(theta, XTest)
    errorTest = compute_error(yPredTest, yTest)
    with open(args.test_out, 'w') as f:
        for pred in yPredTest:
            f.write(str(pred) + '\n')

    with open(args.metrics_out, 'w') as f:
        f.write('error(train): %.6f\n'%errorTrain)
        f.write('error(test): %.6f\n'%errorTest)


